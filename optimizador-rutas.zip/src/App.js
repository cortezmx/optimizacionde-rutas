import React from 'react';
function App() {
  return <h1>Optimizador de Rutas – Sitio Base</h1>;
}
export default App;
